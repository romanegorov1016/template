# Getting Started with "Exercise Tracker" app

## To run this app you have to have Node.js and Node Package Manager (npm) installed locally

To install navigate to: https://nodejs.org/

## Install dependencies:
Navigate to ./backend directory and execute ```npm install```

Navigate to root app directory and execute ```npm install```


## Running App
Navigate to root app directory and execute ```npm run app``` 
